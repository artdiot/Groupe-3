package croisiereBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CroisiereBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
