package croisiereBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CroisiereBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(CroisiereBootApplication.class, args);
	}

}
